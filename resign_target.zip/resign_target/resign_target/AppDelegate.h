//
//  AppDelegate.h
//  RedApp
//
//  Created by bee on 2023/4/13.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>
@property (nonatomic, strong) UIWindow *window;

@end

