//
//  AppDelegate.m
//  RedApp
//
//  Created by bee on 2023/4/13.
//

#import "AppDelegate.h"

#import "ViewController.h"


@interface AppDelegate ()

@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    // Override point for customization after application launch.
    
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    [self.window setRootViewController:[ViewController new]];
    [self.window makeKeyAndVisible];

    
    return YES;
}




@end
